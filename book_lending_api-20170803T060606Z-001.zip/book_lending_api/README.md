#RESTful API using hapi.js and MongoDB

This is the code for this blog-post: [Build a RESTful API using hapi.js and MongoDB](http://mph-web.de/build-a-restful-api-using-hapi-js-and-mongodb/)

##How to setup?

You should have a current version of node installed and a local MongoDB server running. Now just clone the repository and execute these two commands:

```
npm install
node server.js
```
