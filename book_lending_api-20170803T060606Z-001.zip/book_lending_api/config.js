// config.js

const key = 'secretkey';

module.exports = key;